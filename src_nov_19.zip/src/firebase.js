import firebase from 'firebase';
const config =  {apiKey: "AIzaSyDI9mWxIapy9JfuiybxLKQcPp6rSZW-9ow",
    authDomain: "fire-react-1802c.firebaseapp.com",
    databaseURL: "https://fire-react-1802c.firebaseio.com",
    projectId: "fire-react-1802c",
    storageBucket: "fire-react-1802c.appspot.com",
    messagingSenderId: "794358277833",
    appId: "1:794358277833:web:aa8cb247b60c7bebe24f18"}
    firebase.initializeApp(config);
    export default firebase