export const COLORS = {
  yellow: '#fbd40a',
  black: '#000',
 white:'#fff',
  blue: '#1b2c60',
 red:'#F10E07',
 gray:'#F3F3F3',
 half:'#FFFFFD',
 green:'#64C206'
  // your colors
}